<?php
$user=$_SESSION['user'];
//echo $user;
extract($_POST);
if(isset($submit))
{
	$que=mysqli_query($con,"select pass from people_registration where email='$user'");
	$row=mysqli_fetch_object($que);
	$password=$row->pass;
	if($op!=$password)
	{
		$err="wrong old password";
	}
	else if($np!=$cp)
	{
		$err="new pass and cp must same";
	}
	else
	{
		mysqli_query($con,"update people_registration  set pass='$cp' where email='$user'");
		$err="Password Updated Successfully";
	}
}
?>
<form method="post">
<table border="0" bgcolor="#99FFCC" style="margin:30px;">
<tr>
	 <th><?php echo @$err; ?></th>
</tr>
	
<tr>
	<th height="87">Old Password:  
    <input type="password" name="op" value="" placeholder="enter your old password" class="form-control" </th>
</tr>
	
<tr>
	<th height="93">New Password:
    <input type="password" name="np" value="" placeholder="enter your new password" class="form-control" /> <br /></th>
</tr>
 <tr>
	<th height="93">Confirm Password:
    <input type="password" name="cp" value="" placeholder="enter your confirm password" class="form-control" /> <br /></th>
</tr>

<tr>
	<th rowspan="2"><input type="submit" value="Update Password" name="submit" class="btn btn-success"/></th>
</tr>
</table>
</form>
