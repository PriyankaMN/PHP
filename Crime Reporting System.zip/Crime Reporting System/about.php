

    <!-- Navigation -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header" align="center"><font color="#00FF33">ONLINE CRIME REPORTING PORTAL</font> </h1>
                
            </div>
        </div>
        <!-- /.row -->

        <!-- Intro Content -->
        <div class="row" style="margin-bottom:50px">
           
                
                <p>The Police force in the country is entrusted with the responsibility of maintenance of public order and prevention and detection of crimes. Each state and union territory of India has its own separate police force. Article 246 of the Constitution of India (External website that opens in a new window) designates the police as a state subject, which means that the state governments frame the rules and regulations that govern each police force. These rules and regulations are contained in the police manuals of each state force.</p>
                <p>The Police force in the state is headed by the Director General of Police/Inspector General of Police. Each State is divided into convenient territorial divisions called ranges and each police range is under the administrative control of a Deputy Inspector General of Police. A number of districts constitute the range. District police is further sub-divided into police divisions, circles and police-stations.</p>
                <p>The Central Government maintains Central Police forces, Intelligence Bureau (IB), Central Bureau of Investigation (CBI) (External website that opens in a new window), institutions for training of police officers and forensic science institutions to assist the state in gathering intelligence, in maintaining law and order, in investigating special crime cases and in providing training to the senior police officers of the state governments.</p>
            </div>
        </div>
        <!-- /.row -->

        <!-- Footer -->
     