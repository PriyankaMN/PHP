<?php
include('../dbconfig.php');
	
	$info=$_GET['id'];
	//delete all status 
	
	mysqli_query($con,"delete from emergencey_complaint_status where compaint_id='$info'");
	
	mysqli_query($con,"delete from emergency_complaints where id='$info'");
	header('location:dashboard.php?info=emergency_complaints');
?>