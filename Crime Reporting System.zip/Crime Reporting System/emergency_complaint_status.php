<?php 
include('dbconfig.php');

extract($_POST);
if(isset($submit))
{

	$que=mysqli_query($con,"select * from emergencey_complaint_status where compaint_id='$cid'");
	
	$row=mysqli_num_rows($que);
	if($row)
	{
	?>
	<div class="row">
	<div class="col-sm-12" style="color:orange;">
		<h1 align="center" >Emergencey Complaints Details</h1>
	</div>
</div>
<div class="row">
<div class="col-sm-2"></div>
<div class="col-sm-8">

<table class="table table-bordered">

	<thead >
	
	<tr class="success">
		<th>Complaint Id</th>
		<th>Police Officer</th>
		<th>Status</th>
		<th>Date</th>
		</tr>
		</thead>
		
		<?php
	while($row=mysqli_fetch_assoc($que))
		{
			echo "<tr>";
			
			echo "<td>".$row['compaint_id']."</td>";
			echo "<td>".$row['police_officer']."</td>";
			echo "<td>".$row['statuss']."</td>";
			echo "<td>".$row['date']."</td>";
			echo "</tr>";
		}
		
		?>
		
		
		
</table>
</div>
</div>
	
		
<?php 		
	}
	else
	{
	$err="<h2><font color='red'>No Records found  </font></h2>";
	}
}
?>
<form method="post">
<div class="container " style="margin-left:200px">
<h3 style="text-decoration:underline;"><font color="gray">Check emergency complaint status</font></h3>
<div class="row" style="margin-top:10px">
		<div class="col-sm-1"></div>
		<div class="col-sm-3"><?php echo @$err; ?></div>
	</div>
	<div class="row" style="margin-top:10px">
		
	
	<div class="row" style="margin-top:10px">
		
		<div class="col-sm-3">
			<label>Enter Your Mobile No</label>
		</div>
		<div class="col-sm-4">
			<div class="input-group">
				<input type="text" placeholder="enter your mobile " name="mob" class="form-control"/>
			</div>
		</div>
	</div>
	
		<div class="row" style="margin-top:10px">
		<div class="col-sm-3">
			<label>Enter Your Complaint No</label>
		</div>
		<div class="col-sm-4">
			<div class="input-group">
				<input type="text" placeholder="enter your complaint no" name="cid" class="form-control"/>
			</div>
		</div>
	</div>
	
	
	<div class="row" style="margin-top:30px;margin-bottom:60px">
		<div class="col-sm-2"></div>
		<input type="submit" name="submit" value="View Status" class="btn btn-info"/>
	</div>
	
</div>
</form>