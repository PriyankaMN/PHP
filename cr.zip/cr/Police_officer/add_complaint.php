<?php 
error_reporting(1);


extract($_POST);
if(isset($submit))
{			
			$date=$dd."-".$mm."-".$yy;
	
         $query=("insert into user_complaint values('','$offence_name','$offence_last_name','$complaint_subject',
                '$complaint_details','$complaint_place','$date','$email','$contact_number')");
				mysql_query($query);
				echo "<script>alert('data inserted')</script>";
}
?>

		<form method="post" enctype="multipart/form-data">
		<div class="container" style="margin-left:150">
			
			<h3><font color="gray">Fill your requirement...</hr></font></h3>
			<div class="row" style="margin-top:20px">
				<div class="col-sm-2"></div>
			</div>
			<div class="row" style="margin-top:30px">
				
				<div class="col-sm-2">
					<label style="font-size:16px">Enter first name of offence</label>
				</div>
				<div class="col-sm-3">
					<div class="input-group">
						<input type="text" name="offence_name" class="form-control"/>
					</div>
				</div>
				<div class="col-sm-2">
					<label style="font-size:16px">Enter last  name of offence</label>
				</div>
				<div class="col-sm-3">
					<div class="input-group">
						<input type="text" name="offence_last_name" class="form-control"/>
					</div>
				</div>
			</div>
			<div class="row" style="margin-top:20px">
				
				<div class="col-sm-2">
					<label style="font-size:16px">Enter complaint subject</label>
				</div>
				<div class="col-sm-3">
					<div class="input-group">
						<input type="text" name="complaint_subject" class="form-control"/>
					</div>
				</div>
				<div class="col-sm-2" >
					<label style="font-size:16px">Enter Complaint Details</label>
				</div>
				<div class="col-sm-3">
					<div class="input-group">
						<textarea name="complaint_details" rows="5" cols="25"></textarea>
					</div>
				</div>
			</div>
			
			<div class="row" style="margin-top:20px">
				<div class="col-sm-2">
					<label style="font-size:16px">Enter address of complaint place</label>
				</div>
				<div class="col-sm-3">
					<div class="input-group">
						<textarea name="complaint_place" rows="5" cols="25"></textarea>
					</div>
				</div>
				<div class="col-sm-2">
							<label style="font-size:16px;margin-top:30px">Select date</label>
						</div>
						<div class="col-sm-1" style="margin-top:30px">
							<select name="dd" class="form-control">
								<option selected="selected" disabled="disabled">dd</option>
								<?php
								for($i=1;$i<=31;$i++)
								{
									echo "<option>".$i."</option>";
								}
								?>
							</select>
						</div>
					
							<div class="col-sm-1" style="margin-top:30px">
							<select name="mm" class="form-control">
								<option selected="selected" disabled="disabled">mm</option>
								<?php
								$arr=array("jan","feb","march","april","may","june","july","aug","sep","oct","nov","dec");
								for($i=0;$i<count($arr);$i++)
								{
									echo "<option>".$arr[$i]."</option>";
								}
								?>
							</select>
						</div>
						<div class="col-sm-1" style="margin-top:30px">
							<select name="yy" class="form-control">
								<option selected="selected" disabled="disabled">yy</option>
								<?php
								for($i=1980;$i<=2016;$i++)
								{
									echo "<option>".$i."</option>";
								}
								?>
							</select>
					</div>
					
					
			</div>
			
			

			<div class="row" style="margin-top:20px">
			<div class="col-sm-2">
					<label style="font-size:16px">Enter your email id</label>
				</div>
				<div class="col-sm-3">
					<div class="input-group">
						<input type="email" name="email" value="<?php echo $_SESSION['user']?>" disabled class="form-control"/>
					</div>
				</div>
				<div class="col-sm-2">
					<label style="font-size:16px">Contact No</label>
				</div>
				<div class="col-sm-3">
					<div class="input-group">
						<input type="number" name="contact_number" class="form-control"/>
					</div>
				</div>
				<!--<div class="col-sm-2">
							<label style="font-size:16px">Select Gender</label>
						</div>
						<div class="col-sm-3">
							Male<input type="radio" name="gen" value="Boys">
							Female<input type="radio" name="gen" value="Girls"/> 
						</div>
			</div>-->
			<div class="row" style="margin-top:20px">
							
					
			</div>
			
					
						
			<div class="row" style="margin-top:20px">
						
			<div class="row" style="margin-top:20px;margin-bottom:60px">
				<div class="col-sm-5"></div>
				<input type="submit" name="submit" value="Register Me" class="btn btn-info"/>
			</div>
		</div>
		</form>
		
</head>
</html>
