<script>
	function deleteComp(id)
	{
		if(confirm("You want to delete this complaint ?"));
		{
		location.href='delete_complaint.php?id='+id;
		}
	}
</script>
<div class="row">
	<div class="col-sm-12" style="color:orange;">
		<h1 align="center" >Your Complaints Details</h1>
	</div>
</div>
<div class="row">

<div class="col-sm-12">

<table class="table table-bordered">

	<thead >
	<tr  class="danger">
		<th>S.No</th>
		<th>Crime Type</th>
		<th>Crime Date</th>
		<th>Subject</th>
		<th>Details</th>
		<th>Offender_name</th>
		<th>Offender_address</th>
		<th>Witness_name</th>
		<th>Proof_document</th>
		<th>Delete</th>
		<th>View Status</th>
		</tr>
		</thead>
		
		<?php
		$user=$_SESSION['user'];
		$q=mysqli_query($con,"select * from complaints where user='$user'");
		$i=1;
		while($row=mysqli_fetch_assoc($q))
		{
			echo "<tr>";
			echo "<td>".$i."</td>";
			echo "<td>".$row['crime_type']."</td>";
			echo "<td>".$row['crime_date']."</td>";
			echo "<td>".$row['subject']."</td>";
			echo "<td>".$row['details']."</td>";
			echo "<td>".$row['Offender_name']."</td>";
			echo "<td>".$row['Offender_address']."</td>";
			echo "<td>".$row['witness_name']."</td>";
			echo "<td>".$row['proof_documents']."</td>";
			
			?>
			<td><a href='javascript:deleteComp(<?php echo $row['id']; ?>)'>Delete</a></td>
			<?php 
			echo "<td><a href='index.php?info=display_complaint_status&compaint_id=".$row['id']."'>View Status</a></td>";
			echo "</tr>";
			$i++;
		}
		

		

		?>
		
		
		
</table>
</div>
</div>
