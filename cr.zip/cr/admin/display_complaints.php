<script type="text/javascript">
function deletes(id)
{
	a=confirm('Are You Sure To Remove This Record ?')
	 if(a)
     {
        window.location.href='delete_complaint.php?id='+id;
     }
}
</script>	


<?php
	include('../dbconfig.php');
$que=mysqli_query($con,"select * from complaints");		
$r=mysqli_num_rows($que);	
if($r==false)
{
echo "<h2 style='color:red'>No any  complaints at this time</h2>";
}	
else
{	
	
	
	echo "<table class='table table-responsive table-bordered table-striped table-hover' style=margin:15px;>";
	echo "<tr>";
	
	echo "<th>S.No</th>";
	echo "<th>User</th>";
	echo "<th>Crime Type</th>";
	echo "<th>Crime Date</th>";
	echo "<th>Subject</th>";
	echo "<th>Details</th>";
	echo "<th>Offender Name</th>";
	echo "<th>Witness Name</th>";
	echo "<th>Complaint_date</th>";
	echo "<th>Delete</th>";
	echo "<th>View Status</th>";
	
	echo "</tr>";
	
	$i=1;
	
	while($row=mysqli_fetch_array($que))
	{
		echo "<tr>";
		echo "<td>".$i."</td>";
		echo "<td>".$row['user']."</td>";
		echo "<td>".$row['crime_type']."</td>";
		echo "<td>".$row['crime_date']."</td>";
		echo "<td>".$row['subject']."</td>";
		echo "<td>".$row['details']."</td>";
		echo "<td>".$row['Offender_name']."</td>";
		echo "<td>".$row['witness_name']."</td>";
		echo "<td>".$row['Complaint_date']."</td>";
		
		echo "<td class='text-center'><a href='#' onclick='deletes($row[id])'><span class='glyphicon glyphicon-remove' style=color:red;></span></a></td>";
		
		echo "<td><a href='dashboard.php?info=view_complaint_status&complaint_id=".$row['id']."'>View Status</a></td>";
		echo "</tr>";
		$i++;
	}
	
?>
</table>

<?php } ?>