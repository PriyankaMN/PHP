<?php 
$q=mysqli_query($con,"select * from emergencey_complaint_status where compaint_id='".$_GET['cid']."'");
$r=mysqli_num_rows($q);
if($r==false)
{
echo "<h3 style='color:Red'>Status not updated </h3><a href='index.php?info=update_compaint_status&compaint_id=".$_GET['compaint_id']."'>Click here to update Status</a>";
}
else
{
?>
<div class="row">
	<div class="col-sm-12" style="color:orange;">
		<h1 align="center" >Complaints Details</h1>
	</div>
</div>
<div class="row">

<div class="col-sm-12">

<table class="table table-bordered">

	<thead >
	<tr>
		<td colspan="3"><a href='dashboard.php?info=update_emergencey_complaint_status&cid=<?php echo $_GET['cid']; ?>'>Update New Status</a></td>
	</tr>
	<tr class="success">
		<th>Complaint Id</th>
		<th>Status</th>
		<th>Date</th>
		</tr>
		</thead>
		
		<?php
	while($row=mysqli_fetch_assoc($q))
		{
			echo "<tr>";
			
			echo "<td>".$row['compaint_id']."</td>";
			echo "<td>".$row['statuss']."</td>";
			echo "<td>".$row['date']."</td>";
			echo "</tr>";
		}
		
		?>
		
		
		
</table>
</div>
</div>
<?php }?>