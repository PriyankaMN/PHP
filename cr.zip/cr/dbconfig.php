<?php
$con=mysqli_connect("localhost","root","","online_crime")or die(mysqli_error());
?>