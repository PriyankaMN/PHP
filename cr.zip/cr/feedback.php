<?php 
extract($_POST);
if(isset($save))
{
mysqli_query($con,"insert into feedback values('','$name','$mob','$email','$sub','$msg',now())");
	
	$err="<font color='green'>Thank you for  feedback</font>";	

}

?>

        <div class="container">

        <!-- Page Heading/Breadcrumbs -->
        <div class="row">
            <div class="col-lg-12">
                
                <ol class="breadcrumb">
                    
                    </li>
                   
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <!-- Content Row -->
       <div class="row">
            <div class="col-md-8">
                <h3><font color="#00FF33">      <?php echo @$err; ?>
		</font></h3>
                <form  method="post" id="contactForm" >
    
	                <div class="control-group form-group">
                        <div class="controls">
                            <label>Name:</label>
                            <input type="text" class="form-control" name="name" required data-validation-required-message="Please enter your name." required>
                        </div>
                    </div>
					
					<div class="control-group form-group">
                        <div class="controls">
                            <label>Email:</label>
                            <input type="email" class="form-control" name="email" required data-validation-required-message="Please enter your email. " required>
                        </div>
                    </div>
					
					<div class="control-group form-group">
                        <div class="controls">
                            <label>Mobile:</label>
                            <input type="number" class="form-control" name="mob" required data-validation-required-message="Please enter your mobile." required>
                        </div>
                    </div>
					<div class="control-group form-group">
                        <div class="controls">
                            <label>Subject:</label>
                            <input type="text" class="form-control" name="sub" required data-validation-required-message="Please enter your subject." required>
                        </div>
                    </div>
                    <div class="control-group form-group">
                        <div class="controls">
                            <label>Feedback:</label>
                            <textarea rows="10" name="msg" cols="100" class="form-control" id="message" required data-validation-required-message="Please enter your message" maxlength="999" style="resize:none"></textarea>
                        </div>
                    </div>
                    <div id="success"></div>
                    <!-- For success/fail messages -->
                    <button type="submit" name="save" class="btn btn-primary">Send feedback</button>
					<h1></h1>
                </form>
            </div>
			
        </div>

        </div>
        
            <!-- Contact Details Column -->
            
        <!-- /.row -->

        <!-- Contact Form -->
        <!-- In order to set the email address and subject line for the contact form go to the bin/contact_me.php file. -->
        <!-- /.row -->

    <br/><br/>
    
    </div>
    <!-- /.container -->
