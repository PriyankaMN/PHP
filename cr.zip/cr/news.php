<h1 align="center"><font color="#00FF33">News </font></h1>
	<div class="container" style="margin-bottom:50px">
		<div class="row">
			<h4><font color="#0099CC">Contract law</font></h4>
			<p>The main contract law in India is codified in the Indian Contract Act, which came into effect on 1 September 1872 and extends to all India except the state of Jammu and Kashmir. It governs entrance into contract, and effects of breach of contract. 
			</p>
		</div>
		<div class="row">
			<h4><font color="#0099CC">Labour law</font></h4>
			<p>Indian labour law are among the most comprehensive in the world. They have been criticised by the World Bank,[19][20] primarily the grounds of the inflexibility that results from government needing to approve dismissals. 
			</p>
		</div>
		<div class="row">
			<h4><font color="#0099CC">Company law</font></h4>
			<p>It was the view of many in the Indian Independence Movement, including Mahatma Gandhi, that workers had as much of a right to participate in management of firms as shareholders or other property owners.
			</p>
		</div>
		<div class="row">
			<h4><font color="#0099CC">Income Tax Act of 1961</font></h4>
			<p>The major tax enactment in India is the Income Tax Act of 1961 passed by the Parliament, which establishes and governs the taxation of the incomes of individuals and corporations.</p>
		</div>
		<div class="row">
			<h4><font color="#009CC">Police Force</font></h4>
		<p>The federal police are controlled by the central Government of India. The majority of federal law enforcement agencies are controlled by the Ministry of Home Affairs. The head of each of the federal law enforcement agencies is always an Indian Police Service officer (IPS).</p>
		</div>
	</div>