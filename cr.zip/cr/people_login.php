<?php 

extract($_POST);
if(isset($submit))
{
	$que=mysqli_query($con,"select * from people_registration where email='$email' and pass='$password'");
	
	$row=mysqli_num_rows($que);
	$data=mysqli_fetch_array($que);
	if($row)
	{
		//check account is activated or not
		if($data['status'])
		{
	$err="<font color='red'>You did't verify your OTP ! <br/>
	<a href='index.php?info=verify_otp'>Click here to Verify Your Account</a></font>";	
		}
		else
		{
	echo "<script>window.location='Public'</script>";
		 $_SESSION['user']=$email;
		 $_SESSION['data']=$data;
		}
	}
	else
	{
	$err="<font color='red'>Wrong login details</font>";
	}
}
?>
<form method="post">
<div class="container " style="margin-left:200px">
<h3 style="text-decoration:underline;"><font color="gray">Citizen Login Form</font></h3>
<div class="row" style="margin-top:10px">
		<div class="col-sm-1"></div>
		<div class="col-sm-3"><?php echo @$err; ?></div>
	</div>
	<div class="row" style="margin-top:10px">
		
		<div class="col-sm-2">
			<label style="font-size:16px">Citizen Email Id</label>
		</div>
		<div class="col-sm-3">
			<div class="input-group">
				<input type="email" placeholder="enter your email" name="email" class="form-control"/>
			</div>
		</div>
	</div>
	
	<div class="row" style="margin-top:10px">
		
		<div class="col-sm-2">
			<label style="font-size:16px">Citizen password</label>
		</div>
		<div class="col-sm-3">
			<div class="input-group">
				<input type="password" placeholder="enter your password" name="password" class="form-control"/>
			</div>
		</div>
	</div>
	<div class="row" style="margin-top:30px;margin-bottom:60px">
		<div class="col-sm-2"></div>
		<input type="submit" name="submit" value="Login" class="btn btn-info"/>
	</div>
	
</div>
</form>