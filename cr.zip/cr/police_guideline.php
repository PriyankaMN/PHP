<h1 align="center"><font color="#00FF33">Police Guidelines......</font></h1>
<div class="row" style="margin-bottom:50px">
	<div class="col-sm-12">
		<p>Many government and private hospitals provide concessions to the older persons in the treatment of the diseases like cardiac problems, diabetes, kidney problems, blood pressure, joint problems and eye problems. There is also a condition for separate queuing of reservations for hospital beds.</p>

<p>The Indian government gives high rates of interest to its senior citizens on certain savings plans which are run by the post offices and other private banks.</p>


<p>
The Indian government provides housing facilities such as retirement homes and recreational or educational centers. These centers provide older persons with opportunities to spend their free time doing various activities. Most recreational centers have fitness clubs, yoga centers, parks, spiritual sessions, picnics, food fests for the health and entertainment of senior citizens. Some old age homes also have libraries other activities such as music classes, arts and crafts, quizzes and indoor games. These activities help to spiritually uplift seniors and can contribute to overall health improvements and mental stability.[4]</p>
		<p>Poor social interaction with family and friends, poor social networks, and those without families are some difficulties faced by some senior citizens. Social customs based upon elder neglect, which the elderly may internalize as beliefs are topics of concern. Losing the will to live from a lack of social support is another issue.</p>





	</div>
</div>