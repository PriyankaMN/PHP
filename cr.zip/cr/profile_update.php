<?php 
error_reporting(1);
include('dbconfig.php');
session_start();
$a=$_SESSION['user'];
//echo $a;
$que=mysql_query("select * from people_registration where email='$a'");
$row=mysql_fetch_object($que);
	//ho $row->name;
extract($_POST);
if(isset($submit))
	
{
	$q=mysql_query("select * from people_registration where email='$a'");
    $rr=mysql_fetch_object($q);
	mysql_query("update people_registration set name='$name'");
}

?>
<form method="post" enctype="multipart/form-data">
<div class="container" style="margin-left:150">
	
	<h3><font color="#00FF33">People Registreation Form</font></h3>
	<div class="row" style="margin-top:20px">
		<div class="col-sm-2"><?php echo $err;?></div>
	</div>
	<div class="row" style="margin-top:30px">
		
		<div class="col-sm-2">
			<label style="font-size:16px">Citizen First Name</label>
		</div>
		<div class="col-sm-3">
			<div class="input-group">
				<input type="text" name="name" class="form-control" value="<?php echo $row->name;?>"/>
			</div>
		</div>
		<div class="col-sm-2">
			<label style="font-size:16px">Citizen Last Name</label>
		</div>
		<div class="col-sm-3">
			<div class="input-group">
				<input type="text" name="lname" class="form-control" value="<?php echo $row->lname;?>" />
			</div>
		</div>
	</div>
	<div class="row" style="margin-top:20px">
		
		<div class="col-sm-2">
			<label style="font-size:16px">Father Name</label>
		</div>
		<div class="col-sm-3">
			<div class="input-group">
				<input type="text" name="fname" class="form-control" value="<?php echo $row->father_name;?>" />
			</div>
		</div>
		<div class="col-sm-2" >
			<label style="font-size:16px">Mother Name</label>
		</div>
		<div class="col-sm-3">
			<div class="input-group">
				<input type="text" name="mname" class="form-control" value="<?php echo $row->mother_name;?>"/>
			</div>
		</div>
	</div>
	
	<div class="row" style="margin-top:20px">
		<div class="col-sm-2">
			<label style="font-size:16px">Citizen Email</label>
		</div>
		<div class="col-sm-3">
			<div class="input-group">
				<input type="email" name="email" class="form-control" value="<?php echo $row->email;?>"/>
			</div>
		</div>
		<div class="col-sm-2">
			<label style="font-size:16px">Citizen Password</label>
		</div>
		<div class="col-sm-3">
			<div class="input-group">
				<input type="password" name="password" class="form-control" value="<?php echo $row->pass;?>"/>
			</div>
		</div>
	</div>
	<div class="row" style="margin-top:20px">
		
	</div>
	<div class="row" style="margin-top:20px">
		<div class="col-sm-2">
			<label style="font-size:16px">Contact No</label>
		</div>
		<div class="col-sm-3">
			<div class="input-group">
				<input type="number" name="mobile" class="form-control" value="<?php echo $row->mobile;?>"/>
			</div>
		</div>
		<div class="col-sm-2">
					<label style="font-size:16px">Select Gender</label>
				</div>
				<div class="col-sm-3">
					<input type="text" name="" value="<?php echo $row->gender;?>"/>
				</div>
	</div>
	<div class="row" style="margin-top:20px">
		<div class="col-sm-2">
			<label style="font-size:16px">Address</label>
		</div>
		<div class="col-sm-3">
			<div class="input-group">
				<textarea name="address" rows="5" cols="25"><?php echo $row->address;?></textarea>
			</div>
		</div>
			
			
	</div>
	
			
				
							<div class="row" style="margin-top:20px">
				
	<div class="row" style="margin-top:20px;margin-bottom:60px">
		<div class="col-sm-5"></div>
		<input type="submit" name="submit" value="Update Me" class="btn btn-info"/>
	</div>
</div>
</form>