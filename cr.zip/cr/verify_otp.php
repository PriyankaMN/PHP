<?php 
include('dbconfig.php');

extract($_POST);
if(isset($submit))
{
echo $mob." ".$otp;
	$que=mysqli_query($con,"select * from people_registration where mobile='$mob' and otp='$otp'");
	
	$row=mysqli_num_rows($que);
	if($row)
	{
	mysqli_query($con,"update people_registration set status='0' where mobile='$mob'");	
	
	echo "<script>window.location='index.php?info=people_login'</script>";
		
	}
	else
	{
	$err="<font color='red'>Wrong OTP </font>";
	}
}
?>
<form method="post">
<div class="container " style="margin-left:200px">
<h3 style="text-decoration:underline;"><font color="gray">Citizen Login Form</font></h3>
<div class="row" style="margin-top:10px">
		<div class="col-sm-1"></div>
		<div class="col-sm-3"><?php echo @$err; ?></div>
	</div>
	<div class="row" style="margin-top:10px">
		
		<div class="col-sm-2">
			<label style="font-size:16px">Enter Your Mobile No</label>
		</div>
		<div class="col-sm-3">
			<div class="input-group">
				<input type="number" placeholder="enter your mobile no" name="mob" class="form-control"/>
			</div>
		</div>
	</div>
	
	<div class="row" style="margin-top:10px">
		
		<div class="col-sm-2">
			<label style="font-size:16px">Enter Your OTP</label>
		</div>
		<div class="col-sm-3">
			<div class="input-group">
				<input type="text" placeholder="enter your otp" name="otp" class="form-control"/>
			</div>
		</div>
	</div>
	<div class="row" style="margin-top:30px;margin-bottom:60px">
		<div class="col-sm-2"></div>
		<input type="submit" name="submit" value="Verify" class="btn btn-info"/>
	</div>
	
</div>
</form>